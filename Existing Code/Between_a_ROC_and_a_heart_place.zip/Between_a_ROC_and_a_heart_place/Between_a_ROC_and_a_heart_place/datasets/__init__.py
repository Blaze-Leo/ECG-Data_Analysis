#!/usr/bin/python
# -*- coding:utf-8 -*-

from datasets.ECG import ECG
from datasets.ECGag import ECG as ECGag
